﻿declare namespace GrandTheftMultiplayer.Client.Sound {

	class CachedSound {
		readonly AudioData: any[];
		readonly WaveFormat: any;
		constructor(audioFileName: string);
	}

}
