﻿declare namespace GrandTheftMultiplayer.Client.Misc {

	class ModelDimensions {
		Maximum: GrandTheftMultiplayer.Shared.Math.Vector3;
		Minimum: GrandTheftMultiplayer.Shared.Math.Vector3;
		constructor();
	}

}
